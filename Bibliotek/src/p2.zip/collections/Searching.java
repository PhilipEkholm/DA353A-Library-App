
package collections;


/**
 * Klass som söker efter ett objekt i listor
 *
 */
public class Searching {
	/**
	 * Metod som söker efter ett objekt i en ArrayList genom binary sökning
	 * 
	 * @param list
	 *            ArrayList som ska sökas i
	 * @param element
	 *            objekt som ska sökas efter
	 * @return positionen i ArrayListen till objektet
	 */
	public static <E> int binarySearch(ArrayList<E> list, E element) {
		Comparable compare = (Comparable) element;
		int res = -1;
		int low = 0;
		int high = list.size() - 1;
		int pos = 0;

		while ((low < high) && res == -1) { // case1 Element är i miten
			pos = (low + high) / 2;
			if (compare.compareTo(list.get(pos)) == 0)

				return pos;

			else if (compare.compareTo(list.get(pos)) < 0) // case2 Element är
															// mindre
				high = pos - 1;
			else // case3 ELement är större
				low = pos + 1;
		}
		return -1;
	}

	/**
	 * Metod som söker efter ett objekt i en List genom linjär sökning
	 * 
	 * @param list
	 *            List som ska sökas i
	 * @param element
	 *            objekt som ska sökas efter
	 * @return positionen i List till objektet
	 */
	public static <E> int linearSearch(List<E> list, E element) {
		{
			for (int i = 0; i < list.size(); i++) {
				if (element.equals(list.get(i)))
					return i;
			}
			return -1;
		}
	}
}