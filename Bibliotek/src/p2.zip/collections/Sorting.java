package collections;

import collections.ArrayList;

/**
 * Klass som sorterar arrayer genom quicksort och mergesort
 * @author Anas Abu Al-Soud
 *
 */
public class Sorting {
	/**
	 * Sorterar värdena i en double-array, genom att kalla på quicksort-metoden.
	 * @param arr double-arrayen som ska sorteras
	 */
	public static void sort(double[] array) {
		quicksort(array, 0, array.length - 1);

	}
	public static void quicksort(double[] array, int left, int right) {
		int pivoIndex;
		if (left < right) {
			pivoIndex = partition(array, left, right, (left + right) / 2);
			quicksort(array, left, pivoIndex - 1);
			quicksort(array, pivoIndex + 1, right);
		}

	}

	public static int partition(double[] array, int left, int right, int pivoIndex) {
		int storeIndex = left;
		double value = array[pivoIndex];
		swap(array, pivoIndex, right);
		for (int i = left; i < right; i++) {
			if (array[i] < value) {
				swap(array, i, storeIndex);
				storeIndex++;
			}
		}
		swap(array, storeIndex, right);
		return storeIndex;
	}

	public static void swap(double[] array, int pos1, int pos2) {
		double temp = array[pos1];
		array[pos1] = array[pos2];
		array[pos2] = temp;
	}
	/**
	 * Metod som sorterar ArrayList med hjälp av mergesort-metoden
	 * @param list ArrayList som ska sorteras
	 */
	public static <E> void sort(ArrayList<E> list) {
		
		ArrayList<E> temp = new ArrayList<E>(list.size());
		for(int i=0; i<list.size(); i++){
			temp.add(i, list.get(i));
		}
		mergesort(list, 0, list.size(), temp);
		temp = null;
	}

	/**
	 * Metod som använder mergesort för att sortera en ArrayList
	 * @param list ArrayList som ska sorteras
	 * @param start första int i listan som ska sorteras
	 * @param n sista int i listan som ska sorteras
	 * @param temp temporär ArrayList lika stor som list
	 */
	private static <E> void mergesort(ArrayList<E> list, int first, int n, ArrayList<E> temp) {
		int n1;
		int n2;
		if (n > 1) {
			n1 = n / 2;
			n2 = n - n1;
			mergesort(list, first, n1, temp);
			mergesort(list, first + n1, n2, temp);
			merge(list, first, n1, n2, temp);
		}
	}
	

	private static <E> void merge(ArrayList<E> list, int first, int n1, int n2, ArrayList<E> temp) {
		E element;
		int counter = 0, cursor1 = 0, cursor2 = n1, last = n1 + n2;
		while ((cursor1 < n1) && (cursor2 < last)) {
			if (((Comparable<E>) list.get(first + cursor1)).compareTo(list.get(first + cursor2)) > 0) {
				element = list.get(first + cursor1);
				temp.set(counter, element);
				cursor1++;
			} else {
				element = list.get(first + cursor2);
				temp.set(counter, element);
				cursor2++;
			}
			counter++;
		}
	}

}